-- 1) Start by querying all of the data from heroes_information if the Race has an average weight of over 400.

SELECT * FROM heroes_information
WHERE Race IN (SELECT race
FROM heroes_information
GROUP BY race
HAVING AVG(weight) > 400);

-- 2) Create a temporary table for this result called bigs

CREATE TEMPORARY TABLE bigs
SELECT * FROM heroes_information
WHERE Race IN (SELECT race
FROM heroes_information
GROUP BY race
HAVING AVG(weight) > 400);

-- 3) Select all columns and rows from that temporary table.


SELECT * FROM bigs;


-- 4) Write a new query that creates a view that selects the data if the publisher is Marvel Comics 
-- and if their height is above the average height.
 
CREATE VIEW marvel_tall_heroes AS
 SELECT * FROM heroes_information
 WHERE Publisher = 'Marvel Comics'
 AND Height > (
 SELECT AVG(height) FROM heroes_information); 
 
--  Bring that view up.

SELECT * FROM marvel_tall_heroes;



-- 5) Now add an index to the heroes_information table on the name and Race columns.


CREATE INDEX heroname_index ON heroes_information(name(100));

CREATE INDEX race_index ON heroes_information(Race(100));

SHOW INDEXES FROM heroes_information;


-- 6) Finally, create a stored procedure that selects all the data from heroes_information if they are from DC. 
-- Call it all_dc_rows.

DELIMITER !!
CREATE PROCEDURE all_dc_rows
( )
BEGIN 
SELECT * FROM heroes_information
WHERE Publisher = "DC Comics";
END!!

CALL all_dc_rows;

