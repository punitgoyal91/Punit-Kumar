USE hero;

-- 1) Start by returning all rows and columns from the hero_battles data table.

SELECT * FROM hero_battles;

-- 2) Now, return the number of rows in the data set.

SELECT count( * ) FROM hero_battles;

-- 3) Write a query to select the column name’s max and min. Hint: use MIN() and MAX().

USE hero;
SELECT max(num_enemies) AS max_value, min(num_enemies) AS min_value FROM hero_battles;

-- 4) Write a query to select both the sum and the average of the column num_enemies

SELECT sum(num_enemies), avg(num_enemies) FROM hero_battles;

-- 5) Now take that query of the sum and average of enemies, and group it by the column name

SELECT outcome, sum(num_enemies), avg(num_enemies) FROM hero_battles group by outcome;

-- 6) Lastly, take the query we’ve been building and ORDER by the average.

SELECT outcome, sum(num_enemies) AS Sum , avg(num_enemies) AS Average FROM hero_battles
group by outcome order by Average;

