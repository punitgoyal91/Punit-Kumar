
-- -- 1) Start by casting the value “24.423423” to a float value.

SELECT CAST("24.423423" AS FLOAT);

-- -- 2) Next, return the date, time, hour, month, second, and minute data 
-- -- for the hero_battles table based off of the date column. 

USE hero;
SELECT DATE(date) AS date, TIME(date) as time, MONTH(date), 
DAY(date), MINUTE(date), SECOND(date) FROM hero_battles;	

-- 3) Create a histogram for the number of enemies fought. No need to round. 

USE hero;
Select name, COUNT(num_enemies) AS enemycount,
RPAD(' ',COUNT(*),'*') AS bar
FROM hero_battles
GROUP BY name
ORDER BY num_enemies;


-- -- 4) Write a query to replace all of the occurrences of Batman with Batwoman. 
-- Return only the name column. 

USE hero;
SELECT REPLACE (name, "Batman", "Batwoman") as name
from hero_battles;

-- -- 5) Make a new query that creates a sentence that says, 
-- -- “This battle occurred at 14 o’clock,” but replace 14 with the hour of that particular battle. 

USE hero;
Select CONCAT("The battle occured at ", HOUR(date), " 'o clock")
FROM hero_battles;

-- -- 6) Create a query that makes a sentence describing each superhero. State their name, and state what comic series they are from.
-- -- For example, “James Bond is from Titan Books.” Use the heroes_information table and the name and publisher columns. 

USE hero;
Select CONCAT( name, " is from ", Publisher) AS summary FROM heroes_information;



