CREATE DATABASE people_education;

SHOW DATABASES;

USE people_education;
CREATE TABLE people_info
(name VARCHAR(50), 
age INT, 
high_school_attended VARCHAR(250),
height FLOAT);

USE people_education;
CREATE TABLE school_info 
(school_name VARCHAR(250), 
zip_code INT);

USE people_education;
CREATE TABLE school_mascot
 (school_name VARCHAR(250),
 the_school_mascot VARCHAR(30));
 
 SHOW TABLES;
  
 DROP TABLE school_mascot;

USE people_education;
INSERT INTO people_info 
(name, age, high_school_attended, height)
VALUES ("Aswin Kumar", 18 ,"Oakwood High School", 1.65),
("Sarika Devi", 17, " Delhi Public School", 1.58),
("Aditya Sharma", 16, "Trips International School", 1.60),
("Anitha Reddy", 19, "Blossoms International School",1.85),
("Kiran Kumar", 17, "Sunrise Public School", 1.73),
("Lakshmi DevI", 16, "Laurel High School", 1.65),
("Rohan Sharma", 17, "Abhyasa International Residential School",1.72),
("Vijay Raju", 15, "Heritage Global School",1.68),
("Aryan Sharma", 18, "Lotus International School", 1.70),
("Sanya Singh", 16, "Oakridge International School", 1.69);

USE people_education;
INSERT INTO school_info
(school_name, zip_code)
VALUES
("Oakwood High School",533296),
("Delhi Public School",110003),
("Trips International School", 533107),
("Blossoms International School",500133),
("Sunrise Public School", 530011),
("Laurel High Schoo", 533102),
("Abhyasa International Residential School", 502334),
("Heritage Global School", 121004),
("Lotus International School", 533101),
("Oakridge International School",531162);

SHOW TABLES;

SELECT * FROM people_info;
SELECT * FROM school_info;

